package com.mycompany.pulverizafacil

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
