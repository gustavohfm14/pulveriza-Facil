import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'seletor2_model.dart';
export 'seletor2_model.dart';

class Seletor2Widget extends StatefulWidget {
  const Seletor2Widget({super.key});

  @override
  State<Seletor2Widget> createState() => _Seletor2WidgetState();
}

class _Seletor2WidgetState extends State<Seletor2Widget> {
  late Seletor2Model _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => Seletor2Model());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).tertiary,
          automaticallyImplyLeading: false,
          leading: FlutterFlowIconButton(
            borderColor: Colors.transparent,
            borderRadius: 30.0,
            borderWidth: 1.0,
            buttonSize: 60.0,
            icon: Icon(
              Icons.arrow_back_rounded,
              color: Colors.black,
              size: 30.0,
            ),
            onPressed: () async {
              context.pop();
            },
          ),
          title: Text(
            'Seletor de bicos',
            style: FlutterFlowTheme.of(context).headlineMedium.override(
                  fontFamily: 'Inter',
                  color: Colors.black,
                  fontSize: 22.0,
                  letterSpacing: 0.0,
                ),
          ),
          actions: [],
          centerTitle: true,
          elevation: 2.0,
        ),
        body: SafeArea(
          top: true,
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              Align(
                alignment: AlignmentDirectional(-1.0, 0.0),
                child: Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(8.0, 50.0, 0.0, 10.0),
                  child: Text(
                    'Tipo de aplicação:',
                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Readex Pro',
                          fontSize: 20.0,
                          letterSpacing: 0.0,
                        ),
                  ),
                ),
              ),
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(8.0, 16.0, 8.0, 10.0),
                child: FlutterFlowDropDown<String>(
                  controller: _model.dropDownValueController ??=
                      FormFieldController<String>(null),
                  options: [
                    'Fungicida - Sistêmico',
                    'Fungicida - Contato',
                    'Inseticida - Sistêmico',
                    'Inseticida - Contato',
                    'Herbicida - Pré-emergente',
                    'Herbicida - Pós-emergente(Sistêmico)',
                    'Herbicida - Pós-emergente(Contato)'
                  ],
                  onChanged: (val) async {
                    safeSetState(() => _model.dropDownValue = val);
                    FFAppState().tipoAplicacao = _model.dropDownValue!;
                    safeSetState(() {});
                  },
                  width: MediaQuery.sizeOf(context).width * 1.0,
                  height: 55.0,
                  textStyle: FlutterFlowTheme.of(context).bodyMedium.override(
                        fontFamily: 'Readex Pro',
                        color: Colors.black,
                        fontSize: 16.0,
                        letterSpacing: 0.0,
                      ),
                  hintText: 'Selecione um tipo de aplicação',
                  icon: Icon(
                    Icons.keyboard_arrow_down_rounded,
                    color: FlutterFlowTheme.of(context).secondaryText,
                    size: 24.0,
                  ),
                  fillColor: Color(0xFFE1E1E1),
                  elevation: 2.0,
                  borderColor: Colors.black,
                  borderWidth: 2.0,
                  borderRadius: 8.0,
                  margin: EdgeInsetsDirectional.fromSTEB(12.0, 0.0, 12.0, 0.0),
                  hidesUnderline: true,
                  isOverButton: false,
                  isSearchable: false,
                  isMultiSelect: false,
                ),
              ),
              Divider(
                thickness: 2.0,
                color: Colors.black,
              ),
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(16.0, 396.0, 16.0, 0.0),
                child: FFButtonWidget(
                  onPressed: () async {
                    await Future.wait([
                      Future(() async {
                        if (FFAppState().tipoAplicacao ==
                            'Inseticida - Sistêmico') {
                          context.pushNamed('inseticidaSist');
                        }
                      }),
                      Future(() async {
                        if (FFAppState().tipoAplicacao ==
                            'Inseticida - Contato') {
                          context.pushNamed('inseticidaCont');
                        }
                      }),
                    ]);
                    await Future.wait([
                      Future(() async {
                        if (FFAppState().tipoAplicacao ==
                            'Fungicida - Sistêmico') {
                          context.pushNamed('fungicidaSist');
                        }
                      }),
                      Future(() async {
                        if (FFAppState().tipoAplicacao ==
                            'Fungicida - Contato') {
                          context.pushNamed('fungicidaCont');
                        }
                      }),
                    ]);
                    await Future.wait([
                      Future(() async {
                        if (FFAppState().tipoAplicacao ==
                            'Herbicida - Pré-emergente') {
                          context.pushNamed('herbPre');
                        }
                      }),
                      Future(() async {
                        await Future.wait([
                          Future(() async {
                            if (FFAppState().tipoAplicacao ==
                                'Herbicida - Pós-emergente(Sistêmico)') {
                              context.pushNamed('herbPosSist');
                            }
                          }),
                          Future(() async {
                            if (FFAppState().tipoAplicacao ==
                                'Herbicida - Pós-emergente(Contato)') {
                              context.pushNamed('herbPosCont');
                            }
                          }),
                        ]);
                      }),
                    ]);
                  },
                  text: 'Próximo',
                  options: FFButtonOptions(
                    width: MediaQuery.sizeOf(context).width * 1.0,
                    height: 60.0,
                    padding:
                        EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                    iconPadding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                    color: FlutterFlowTheme.of(context).tertiary,
                    textStyle: FlutterFlowTheme.of(context).titleSmall.override(
                          fontFamily: 'Readex Pro',
                          color: Colors.black,
                          fontSize: 25.0,
                          letterSpacing: 0.0,
                        ),
                    elevation: 0.0,
                    borderSide: BorderSide(
                      color: Colors.black,
                      width: 2.0,
                    ),
                    borderRadius: BorderRadius.circular(20.0),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
