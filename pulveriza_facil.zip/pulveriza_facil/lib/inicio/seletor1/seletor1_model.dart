import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'seletor1_widget.dart' show Seletor1Widget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'package:provider/provider.dart';

class Seletor1Model extends FlutterFlowModel<Seletor1Widget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for velocidadeAplicacao widget.
  FocusNode? velocidadeAplicacaoFocusNode;
  TextEditingController? velocidadeAplicacaoTextController;
  final velocidadeAplicacaoMask = MaskTextInputFormatter(mask: '##');
  String? Function(BuildContext, String?)?
      velocidadeAplicacaoTextControllerValidator;
  // State field(s) for vazaoAplicacao widget.
  FocusNode? vazaoAplicacaoFocusNode;
  TextEditingController? vazaoAplicacaoTextController;
  final vazaoAplicacaoMask = MaskTextInputFormatter(mask: '###');
  String? Function(BuildContext, String?)?
      vazaoAplicacaoTextControllerValidator;
  // State field(s) for espacamento widget.
  FocusNode? espacamentoFocusNode;
  TextEditingController? espacamentoTextController;
  final espacamentoMask = MaskTextInputFormatter(mask: '##');
  String? Function(BuildContext, String?)? espacamentoTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    velocidadeAplicacaoFocusNode?.dispose();
    velocidadeAplicacaoTextController?.dispose();

    vazaoAplicacaoFocusNode?.dispose();
    vazaoAplicacaoTextController?.dispose();

    espacamentoFocusNode?.dispose();
    espacamentoTextController?.dispose();
  }
}
