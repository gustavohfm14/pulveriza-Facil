import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {}

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  int _vazao = 0;
  int get vazao => _vazao;
  set vazao(int value) {
    _vazao = value;
  }

  int _velocidade = 0;
  int get velocidade => _velocidade;
  set velocidade(int value) {
    _velocidade = value;
  }

  String _tipoAplicacao = '';
  String get tipoAplicacao => _tipoAplicacao;
  set tipoAplicacao(String value) {
    _tipoAplicacao = value;
  }

  int _espacamento = 0;
  int get espacamento => _espacamento;
  set espacamento(int value) {
    _espacamento = value;
  }
}
