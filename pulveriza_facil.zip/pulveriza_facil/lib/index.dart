// Export pages
export '/inicio/inicio/inicio_widget.dart' show InicioWidget;
export '/inicio/seletor1/seletor1_widget.dart' show Seletor1Widget;
export '/inicio/seletor2/seletor2_widget.dart' show Seletor2Widget;
export '/recomendacoes/herb_pos_sist/herb_pos_sist_widget.dart'
    show HerbPosSistWidget;
export '/recomendacoes/herb_pre/herb_pre_widget.dart' show HerbPreWidget;
export '/recomendacoes/herb_pos_cont/herb_pos_cont_widget.dart'
    show HerbPosContWidget;
export '/recomendacoes/fungicida_cont/fungicida_cont_widget.dart'
    show FungicidaContWidget;
export '/recomendacoes/inseticida_cont/inseticida_cont_widget.dart'
    show InseticidaContWidget;
export '/recomendacoes/fungicida_sist/fungicida_sist_widget.dart'
    show FungicidaSistWidget;
export '/recomendacoes/inseticida_sist/inseticida_sist_widget.dart'
    show InseticidaSistWidget;
export '/bicos/ad/ad_widget.dart' show AdWidget;
export '/bicos/mga/mga_widget.dart' show MgaWidget;
export '/bicos/st/st_widget.dart' show StWidget;
export '/bicos/ch/ch_widget.dart' show ChWidget;
export '/bicos/cv_ia/cv_ia_widget.dart' show CvIaWidget;
export '/bicos/ad_ia/ad_ia_widget.dart' show AdIaWidget;
export '/inicio/z_catalogo/z_catalogo_widget.dart' show ZCatalogoWidget;
